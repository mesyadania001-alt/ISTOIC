
import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';

interface SharedQRCodeProps {
    value: string;
    size?: number;
    className?: string;
}

export const SharedQRCode: React.FC<SharedQRCodeProps> = ({ value, size = 220, className = "" }) => {
    const [imgSrc, setImgSrc] = useState<string | null>(null);

    useEffect(() => {
        if (!value) return;
        // Use a slight delay or async to prevent blocking UI if generating large QR
        QRCode.toDataURL(value, {
            width: size,
            margin: 2,
            color: { dark: '#000000', light: '#FFFFFF' },
            errorCorrectionLevel: 'M'
        }).then(setImgSrc).catch((err) => {
            console.error("QR Gen Error:", err);
        });
    }, [value, size]);

    if (!imgSrc) {
        return (
            <div 
                className={`bg-white/10 animate-pulse rounded-xl ${className}`} 
                style={{ width: size, height: size }}
            />
        );
    }

    return (
        <img 
            src={imgSrc} 
            alt="QR Code" 
            className={`rounded-xl shadow-inner mix-blend-screen block pointer-events-auto select-none bg-white ${className}`} 
            style={{ width: size, height: size }} 
        />
    );
};

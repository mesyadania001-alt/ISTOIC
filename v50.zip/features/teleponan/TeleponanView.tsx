import React, { useState, useEffect, useRef } from 'react';
import { 
    Phone, PhoneOff, Mic, MicOff, ShieldCheck, Activity, 
    Volume2, Volume1, CloudRain, Lock, Zap, Radio, 
    Fingerprint, Users, Disc, ShieldAlert, Ear, X, ThumbsUp,
    Wifi, WifiOff, RefreshCw
} from 'lucide-react';
import { generateSAS } from '../../utils/crypto';
import { SharedQRCode } from '../../components/SharedQRCode';

type CallState = 'IDLE' | 'SIGNALING' | 'RINGING' | 'CONNECTED' | 'SECURE_HANDSHAKE' | 'TERMINATED' | 'RECONNECTING';
type VoiceEffect = 'NORMAL' | 'DEEP_COVER' | 'CYBER_MASK';

interface TeleponanProps {
    onClose: () => void;
    existingPeer?: any;
    initialTargetId?: string;
    incomingCall?: any;
}

// --- UTILS: METERED.CA TURN FETCHER (FORCE TCP/TLS) ---
const fetchMeteredIce = async (): Promise<any[]> => {
    const apiKey = (import.meta as any).env.VITE_METERED_API_KEY;
    const domain = (import.meta as any).env.VITE_METERED_DOMAIN;

    if (!apiKey || !domain) {
        return [];
    }

    try {
        const response = await fetch(`https://${domain}/api/v1/turn/credentials?apiKey=${apiKey}`);
        if (!response.ok) throw new Error("Metered API Failed");
        const iceServers = await response.json();
        
        const optimizedServers = iceServers.map((server: any) => {
            if (server.urls) {
                const urls = Array.isArray(server.urls) ? server.urls : [server.urls];
                const tcpUrls = urls.map((u: string) => {
                    if (u.startsWith('turn:') && !u.includes('transport=')) {
                        return `${u}?transport=tcp`;
                    }
                    if (u.startsWith('turns:') && !u.includes('transport=')) {
                        return `${u}?transport=tcp`;
                    }
                    return u;
                });
                return { ...server, urls: tcpUrls };
            }
            return server;
        });

        return optimizedServers;
    } catch (e) {
        return [];
    }
};

// --- AUDIO ENGINE CLASS ---
class TeleponanAudioEngine {
    ctx: AudioContext;
    micSource: MediaStreamAudioSourceNode | null = null;
    destination: MediaStreamAudioDestinationNode | null = null;
    gainNode: GainNode;
    compressor: DynamicsCompressorNode;
    filter: BiquadFilterNode;
    rainNode: AudioBufferSourceNode | null = null;
    rainGain: GainNode;
    
    constructor() {
        const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
        this.ctx = new AudioContextClass({ latencyHint: 'interactive', sampleRate: 16000 });
        this.gainNode = this.ctx.createGain();
        this.rainGain = this.ctx.createGain();
        this.compressor = this.ctx.createDynamicsCompressor();
        this.filter = this.ctx.createBiquadFilter();
        
        this.compressor.threshold.value = -50;
        this.compressor.knee.value = 40;
        this.compressor.ratio.value = 12;
        this.compressor.attack.value = 0;
        this.compressor.release.value = 0.25;
        
        this.rainGain.gain.value = 0;
        this.rainGain.connect(this.ctx.destination);
    }

    async initMic(stream: MediaStream) {
        if (this.ctx.state === 'suspended') await this.ctx.resume();
        // Clean up previous nodes if reusing engine (though we usually recreate)
        if (this.micSource) this.micSource.disconnect();
        
        this.micSource = this.ctx.createMediaStreamSource(stream);
        this.destination = this.ctx.createMediaStreamDestination();
        this.micSource.connect(this.filter);
        this.filter.connect(this.compressor);
        this.compressor.connect(this.gainNode);
        this.gainNode.connect(this.destination);
        return this.destination.stream;
    }

    setVoiceEffect(effect: VoiceEffect) {
        const t = this.ctx.currentTime;
        if (effect === 'NORMAL') {
            this.filter.type = 'allpass';
            this.filter.frequency.setValueAtTime(0, t);
        } else if (effect === 'DEEP_COVER') {
            this.filter.type = 'lowpass';
            this.filter.frequency.setValueAtTime(600, t);
            this.filter.Q.value = 1;
        } else if (effect === 'CYBER_MASK') {
            this.filter.type = 'bandpass';
            this.filter.frequency.setValueAtTime(1200, t);
            this.filter.Q.value = 5;
        }
    }

    toggleRain(enable: boolean) {
        if (enable) {
            const bufferSize = 2 * this.ctx.sampleRate;
            const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
            const output = buffer.getChannelData(0);
            let lastOut = 0;
            for (let i = 0; i < bufferSize; i++) {
                const white = Math.random() * 2 - 1;
                output[i] = (lastOut + (0.02 * white)) / 1.02;
                lastOut = output[i];
                output[i] *= 3.5; 
            }
            this.rainNode = this.ctx.createBufferSource();
            this.rainNode.buffer = buffer;
            this.rainNode.loop = true;
            this.rainNode.connect(this.rainGain);
            this.rainNode.start();
            this.rainGain.gain.setTargetAtTime(0.15, this.ctx.currentTime, 1);
        } else {
            if (this.rainNode) {
                this.rainGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.5);
                setTimeout(() => { try{ this.rainNode?.stop(); }catch(e){} }, 600);
            }
        }
    }

    cleanup() { 
        try { 
            this.micSource?.disconnect();
            this.destination?.disconnect();
            this.ctx.close(); 
        } catch(e){} 
    }
}

export const TeleponanView: React.FC<TeleponanProps> = ({ onClose, existingPeer, initialTargetId, incomingCall }) => {
    const [state, setState] = useState<CallState>('IDLE');
    const [myId, setMyId] = useState('');
    const [targetId, setTargetId] = useState(initialTargetId || '');
    const [isMuted, setIsMuted] = useState(false);
    const [voiceEffect, setVoiceEffect] = useState<VoiceEffect>('NORMAL');
    const [isRainActive, setIsRainActive] = useState(false);
    const [sasCode, setSasCode] = useState<string | null>(null);
    const [isSasVerified, setIsSasVerified] = useState(false);
    const [connectionQuality, setConnectionQuality] = useState(100);
    const [dataUsage, setDataUsage] = useState(0);

    const peerRef = useRef<any>(null);
    const callRef = useRef<any>(null);
    const audioRef = useRef<HTMLAudioElement>(null);
    const engineRef = useRef<TeleponanAudioEngine | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const timerRef = useRef<any>(null);
    const lastNetworkType = useRef<string | null>(null);

    // --- NETWORK & RECONNECT LOGIC ---
    useEffect(() => {
        const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
        
        const handleNetworkChange = () => {
             const currentType = connection ? connection.effectiveType : 'unknown';
             
             // Detect switch (e.g. 'wifi' -> '4g') or offline -> online
             if (lastNetworkType.current && lastNetworkType.current !== currentType) {
                 console.log(`[TELEPONAN] Network Handover: ${lastNetworkType.current} -> ${currentType}`);
                 handleHandover();
             }
             lastNetworkType.current = currentType;
        };

        if (connection) {
            lastNetworkType.current = connection.effectiveType;
            connection.addEventListener('change', handleNetworkChange);
        }
        
        window.addEventListener('online', () => {
            console.log("[TELEPONAN] Network Online. Attempting recovery.");
            handleHandover();
        });

        return () => {
             if (connection) connection.removeEventListener('change', handleNetworkChange);
             window.removeEventListener('online', () => {});
        };
    }, [state, targetId]);

    const handleHandover = () => {
        if (state === 'CONNECTED' || state === 'SECURE_HANDSHAKE') {
            console.log("[HYDRA-LINK] Call dropped due to network switch. Initiating rapid reconnect...");
            setState('RECONNECTING');
            
            // Clean up old streams immediately
            if (callRef.current) callRef.current.close();
            
            // Auto-Redial Logic (Caller Side)
            if (targetId && !incomingCall) {
                // Wait briefly for network stabilization
                setTimeout(() => {
                    console.log("[HYDRA-LINK] Dialing target again...");
                    makeCall();
                }, 2000);
            } 
            // Callee Side: Stay in RECONNECTING and wait for new incoming call from parent
        }
    };

    // React to new incoming calls (used for initial pick-up AND reconnection)
    useEffect(() => {
        if (incomingCall) {
            // If we are in IDLE, normal ring.
            if (state === 'IDLE') {
                handleIncomingCall(incomingCall, false);
            }
            // If we are RECONNECTING, auto-accept to restore session
            else if (state === 'RECONNECTING') {
                console.log("[HYDRA-LINK] Reconnection received. Auto-accepting...");
                handleIncomingCall(incomingCall, true);
            }
        }
    }, [incomingCall, state]);


    // --- INITIALIZATION ---
    useEffect(() => {
        const init = async () => {
            if (existingPeer) {
                peerRef.current = existingPeer;
                setMyId(existingPeer.id);
                
                // If this component mounted with an incoming call immediately
                if (incomingCall && state === 'IDLE') {
                    await handleIncomingCall(incomingCall, false);
                } else if (initialTargetId && state === 'IDLE') {
                    // Auto-dial if target provided (and we are caller)
                     setTimeout(() => makeCall(), 500); 
                }
            } else {
                // STANDALONE MODE
                const { Peer } = await import('peerjs');
                
                let iceServers: any[] = [];
                let policy: 'all' | 'relay' = 'all';

                try {
                    const meteredServers = await fetchMeteredIce();
                    if (meteredServers.length > 0) {
                        iceServers = [...meteredServers];
                        policy = 'relay';
                    } else {
                        iceServers = [{ urls: 'stun:stun.l.google.com:19302' }];
                        policy = 'all';
                    }
                } catch (e) {
                    iceServers = [{ urls: 'stun:stun.l.google.com:19302' }];
                }

                const peer = new Peer(undefined, {
                    debug: 0,
                    secure: true,
                    config: {
                        iceServers: iceServers,
                        sdpSemantics: 'unified-plan',
                        iceTransportPolicy: policy,
                        iceCandidatePoolSize: 10
                    }
                });

                peer.on('open', (id) => setMyId(id));
                peer.on('call', (call) => handleIncomingCall(call));
                peerRef.current = peer;
            }
        };
        init();
        return () => { if(!existingPeer) terminateCall(); }; 
    }, []); // Run once on mount

    const handleIncomingCall = async (call: any, autoAnswer = false) => {
        if (!autoAnswer) {
             setState('RINGING');
             // Play Ringtone?
        }
        
        const acceptCall = async () => {
            await startAudio();
            if (engineRef.current?.destination?.stream) {
                call.answer(engineRef.current.destination.stream);
                setupCallEvents(call);
            }
        };

        if (autoAnswer) {
            acceptCall();
        } else {
             // Delay confirm to let UI render Ringing state
             setTimeout(() => {
                 const confirmed = window.confirm("SECURE INCOMING CALL. ACCEPT?");
                 if (confirmed) {
                     acceptCall();
                 } else {
                     call.close();
                     setState('IDLE');
                     if(existingPeer) onClose();
                 }
             }, 100);
        }
    };

    const startAudio = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: { 
                    echoCancellation: true, noiseSuppression: true, autoGainControl: true, sampleRate: 16000 
                }, 
                video: false 
            });
            streamRef.current = stream;
            // Clean old engine if exists
            if (engineRef.current) engineRef.current.cleanup();
            
            engineRef.current = new TeleponanAudioEngine();
            await engineRef.current.initMic(stream);
            return stream;
        } catch (e) {
            alert("MIC ACCESS DENIED. SECURE CHANNEL FAILED.");
            return null;
        }
    };

    const setupCallEvents = (call: any) => {
        callRef.current = call;
        
        // ICE State Monitoring for Handover
        call.peerConnection.oniceconnectionstatechange = () => {
            const iceState = call.peerConnection.iceConnectionState;
            console.log("[ICE STATE]", iceState);
            if (iceState === 'disconnected' || iceState === 'failed') {
                 console.warn("[TELEPONAN] ICE Failure detected. Attempting handover.");
                 handleHandover();
            }
        };

        call.on('stream', (remoteStream: MediaStream) => {
            if (audioRef.current) {
                audioRef.current.srcObject = remoteStream;
                audioRef.current.play().catch(e => console.log("Autoplay blocked", e));
                setState('CONNECTED');
                generateSecurityVisuals(call.peer);
                startDataCounter();
            }
        });
        
        // Only terminate if explicit close, not network error (which we handle via ICE state)
        call.on('close', () => {
            if (state !== 'RECONNECTING') terminateCall();
        });
        
        call.on('error', (err: any) => {
             console.error("Call Error", err);
             // If error is network related, handover logic might already be triggered by ICE state
             // Otherwise terminate
             if (state !== 'RECONNECTING') terminateCall();
        });
    };

    const makeCall = async () => {
        if (!targetId || !peerRef.current) return;
        setState('SIGNALING');
        await startAudio();
        
        if (engineRef.current?.destination?.stream) {
            const call = peerRef.current.call(targetId, engineRef.current.destination.stream, {
                metadata: { security: 'AES-256', version: '25.0', type: 'audio' }
            });
            setupCallEvents(call);
        }
    };

    const terminateCall = () => {
        setState('TERMINATED');
        callRef.current?.close();
        if (!existingPeer) peerRef.current?.destroy(); 
        engineRef.current?.cleanup();
        streamRef.current?.getTracks().forEach(t => t.stop());
        clearInterval(timerRef.current);
        setTimeout(() => { if (onClose) onClose(); }, 2000);
    };

    const generateSecurityVisuals = async (peerId: string) => {
        const sas = await generateSAS(myId || (peerRef.current?.id), peerId, 'SHARED_SECRET_PHRASE'); 
        setSasCode(sas);
        setState('SECURE_HANDSHAKE');
        const interval = setInterval(() => { setConnectionQuality(Math.floor(Math.random() * (100 - 80) + 80)); }, 2000);
        return () => clearInterval(interval);
    };

    const startDataCounter = () => {
        if (timerRef.current) clearInterval(timerRef.current);
        timerRef.current = setInterval(() => { setDataUsage(prev => prev + 0.002); }, 1000);
    };

    const toggleMute = () => {
        if (streamRef.current) {
            streamRef.current.getAudioTracks()[0].enabled = !streamRef.current.getAudioTracks()[0].enabled;
            setIsMuted(!isMuted);
        }
    };

    const cycleVoiceEffect = () => {
        const effects: VoiceEffect[] = ['NORMAL', 'DEEP_COVER', 'CYBER_MASK'];
        const next = effects[(effects.indexOf(voiceEffect) + 1) % effects.length];
        setVoiceEffect(next);
        engineRef.current?.setVoiceEffect(next);
    };

    const toggleRain = () => {
        const next = !isRainActive;
        setIsRainActive(next);
        engineRef.current?.toggleRain(next);
    };

    return (
        <div className="fixed inset-0 z-[9999] bg-black text-green-500 font-mono flex flex-col overflow-hidden">
            <audio ref={audioRef} className="hidden" />
            
            {/* Background Animations */}
            <div className="absolute inset-0 pointer-events-none opacity-20">
                <div className="absolute top-0 left-0 w-full h-[2px] bg-green-500 animate-[scan_3s_linear_infinite] shadow-[0_0_20px_#00ff00]"></div>
                <div className="absolute inset-0 bg-[linear-gradient(transparent_2px,#000_2px)] bg-[length:100%_4px]"></div>
            </div>

            {/* Reconnecting Overlay */}
            {state === 'RECONNECTING' && (
                <div className="absolute top-0 left-0 right-0 z-50 bg-amber-500/90 text-black p-4 text-center animate-slide-down shadow-lg backdrop-blur-md">
                    <div className="flex flex-col items-center gap-2">
                        <div className="flex items-center justify-center gap-3">
                            <WifiOff size={24} className="animate-pulse" />
                            <span className="text-sm font-black uppercase tracking-widest">SIGNAL LOST. HYDRA-LINK RECONNECTING...</span>
                        </div>
                        <p className="text-[10px] font-mono">DO NOT CLOSE. REROUTING PACKETS.</p>
                        {targetId && (
                            <div className="flex items-center gap-2 mt-2">
                                <Loader2 size={12} className="animate-spin" />
                                <span className="text-[10px] font-bold">RE-DIALING {targetId.slice(0,6)}...</span>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Header */}
            <div className="px-6 pb-6 pt-[calc(env(safe-area-inset-top)+1.5rem)] border-b border-green-900/50 flex justify-between items-center bg-black/80 backdrop-blur-md relative z-10">
                <div className="flex items-center gap-4">
                    <div className={`w-3 h-3 rounded-full shadow-[0_0_10px_#00ff00] ${state === 'RECONNECTING' ? 'bg-amber-500 animate-pulse' : 'bg-green-500'}`}></div>
                    <h1 className="text-xl font-black uppercase tracking-[0.2em]">SECURE_LINE_v25</h1>
                </div>
                <div className="flex items-center gap-4 text-xs font-bold">
                    <span className="flex items-center gap-2"><ShieldCheck size={14}/> {existingPeer ? "INTEGRATED" : "STANDALONE"}</span>
                    <span className="text-green-700">|</span>
                    <span className="flex items-center gap-2"><Activity size={14}/> {connectionQuality}%</span>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 flex flex-col items-center justify-center relative z-10 p-6 pb-safe">
                {state === 'IDLE' && (
                    <div className="w-full max-w-md space-y-8 animate-fade-in">
                        <div className="text-center space-y-2">
                            <div className="w-24 h-24 mx-auto rounded-full border-2 border-dashed border-green-500/50 flex items-center justify-center animate-[spin_10s_linear_infinite]">
                                <Fingerprint size={48} className="text-green-500" />
                            </div>
                            <h2 className="text-2xl font-black tracking-tighter">WAITING FOR UPLINK</h2>
                            <p className="text-xs text-green-700">{existingPeer ? "USING ISTOK CONNECTION" : "SHARE ID OR ENTER TARGET COORDINATES"}</p>
                        </div>
                        <div className="p-6 border border-green-900/50 bg-green-900/10 rounded-xl space-y-4">
                            {!existingPeer && (
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black uppercase tracking-widest">MY_IDENTIFIER</label>
                                    <div className="flex gap-2">
                                        <code className="flex-1 bg-black/50 p-3 rounded border border-green-900 text-xs select-all">{myId || 'GENERATING...'}</code>
                                        <button onClick={() => navigator.clipboard.writeText(myId)} className="p-3 bg-green-900/30 hover:bg-green-500/20 rounded border border-green-900 transition-all"><Users size={16}/></button>
                                    </div>
                                </div>
                            )}
                            <div className="space-y-2">
                                <label className="text-[10px] font-black uppercase tracking-widest">TARGET_IDENTIFIER</label>
                                <input value={targetId} onChange={e => setTargetId(e.target.value)} className="w-full bg-black/50 p-3 rounded border border-green-900 text-xs focus:outline-none focus:border-green-500 transition-all placeholder:text-green-900" placeholder="PASTE_ID_HERE" />
                            </div>
                            <button onClick={makeCall} disabled={!targetId} className="w-full py-4 bg-green-600 hover:bg-green-500 text-black font-black uppercase tracking-[0.2em] rounded shadow-[0_0_20px_rgba(0,255,0,0.3)] transition-all disabled:opacity-50 flex items-center justify-center gap-3">
                                <Phone size={18} fill="currentColor"/> INITIATE_CALL
                            </button>
                        </div>
                    </div>
                )}

                {(state === 'SIGNALING' || state === 'RINGING') && (
                    <div className="text-center space-y-6 animate-pulse">
                        <Radio size={64} className="mx-auto text-green-500" />
                        <h2 className="text-3xl font-black uppercase tracking-widest">ESTABLISHING...</h2>
                        <p className="text-xs font-mono text-green-600">HANDSHAKE_PROTOCOL_INITIATED</p>
                    </div>
                )}

                {(state === 'CONNECTED' || state === 'SECURE_HANDSHAKE' || state === 'RECONNECTING') && (
                    <div className={`w-full max-w-lg space-y-8 relative ${state === 'RECONNECTING' ? 'opacity-50 grayscale' : ''}`}>
                        <div className="relative h-48 border border-green-900/50 bg-black/50 rounded-2xl overflow-hidden flex items-center justify-center group">
                            <div className="absolute inset-0 flex items-center gap-1 justify-center opacity-30">
                                {Array.from({length: 20}).map((_,i) => (
                                    <div key={i} className="w-2 bg-green-500 animate-[music-bar_0.5s_ease-in-out_infinite]" style={{ height: `${Math.random() * 100}%`, animationDelay: `${i * 0.05}s` }}></div>
                                ))}
                            </div>
                            
                            <div className="relative z-10 text-center space-y-2 p-6 bg-black/80 backdrop-blur border border-green-500/30 rounded-xl shadow-[0_0_30px_rgba(0,255,0,0.1)] max-w-xs">
                                {isSasVerified ? (
                                    <div className="text-emerald-500 flex flex-col items-center gap-2">
                                        <Lock size={32} />
                                        <span className="text-xs font-black uppercase tracking-widest">ENCRYPTION VERIFIED</span>
                                    </div>
                                ) : (
                                    <>
                                        <div className="flex items-center justify-center gap-2 mb-2">
                                            <ShieldAlert size={16} className="text-amber-500" />
                                            <span className="text-[10px] font-black uppercase tracking-widest text-amber-500">VERIFY IDENTITY</span>
                                        </div>
                                        {sasCode && (
                                            <div className="text-3xl font-mono font-bold tracking-widest text-white">
                                                {sasCode}
                                            </div>
                                        )}
                                        <p className="text-[8px] text-green-600 uppercase mb-3">READ THIS CODE TO PEER</p>
                                        <button 
                                            onClick={() => setIsSasVerified(true)}
                                            className="px-4 py-2 bg-green-600/20 hover:bg-green-600 text-green-500 hover:text-black rounded-lg text-[9px] font-black uppercase tracking-widest transition-all border border-green-600/50 flex items-center justify-center gap-2 w-full"
                                        >
                                            <ThumbsUp size={12} /> CONFIRM MATCH
                                        </button>
                                    </>
                                )}
                            </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <button onClick={toggleMute} className={`p-6 rounded-xl border flex flex-col items-center gap-2 transition-all ${isMuted ? 'bg-red-900/20 border-red-500 text-red-500' : 'bg-green-900/10 border-green-900 hover:border-green-500 hover:text-white'}`}>
                                {isMuted ? <MicOff size={24}/> : <Mic size={24}/>}
                                <span className="text-[8px] font-black uppercase tracking-widest">MUTE</span>
                            </button>

                            <button onClick={cycleVoiceEffect} className={`p-6 rounded-xl border flex flex-col items-center gap-2 transition-all ${voiceEffect !== 'NORMAL' ? 'bg-purple-900/20 border-purple-500 text-purple-400' : 'bg-green-900/10 border-green-900 hover:border-green-500'}`}>
                                <Disc size={24} className={voiceEffect !== 'NORMAL' ? 'animate-spin-slow' : ''}/>
                                <span className="text-[8px] font-black uppercase tracking-widest">{voiceEffect}</span>
                            </button>

                            <button onClick={toggleRain} className={`p-6 rounded-xl border flex flex-col items-center gap-2 transition-all ${isRainActive ? 'bg-blue-900/20 border-blue-500 text-blue-400' : 'bg-green-900/10 border-green-900 hover:border-green-500'}`}>
                                <CloudRain size={24} className={isRainActive ? 'animate-bounce' : ''}/>
                                <span className="text-[8px] font-black uppercase tracking-widest">ISOLATION</span>
                            </button>

                            <button onClick={() => {}} className="p-6 rounded-xl border bg-green-900/10 border-green-900 flex flex-col items-center gap-2 opacity-50 cursor-not-allowed">
                                <Ear size={24}/>
                                <span className="text-[8px] font-black uppercase tracking-widest">SPEAKER</span>
                            </button>
                        </div>

                        <div className="flex justify-between items-center text-[10px] text-green-700 font-mono border-t border-green-900/50 pt-4">
                            <span>DATA_USAGE: {dataUsage.toFixed(2)} MB</span>
                            <span>CODEC: OPUS_16K_VBR</span>
                        </div>

                        <button onClick={terminateCall} className="w-full py-6 bg-red-600 hover:bg-red-500 text-white rounded-xl font-black uppercase tracking-[0.3em] shadow-[0_0_30px_rgba(255,0,0,0.4)] transition-all flex items-center justify-center gap-4 active:scale-95">
                            <PhoneOff size={24} fill="currentColor" /> TERMINATE_UPLINK
                        </button>
                    </div>
                )}

                {state === 'TERMINATED' && (
                    <div className="text-center space-y-4">
                        <ShieldAlert size={64} className="mx-auto text-red-500 animate-pulse" />
                        <h2 className="text-3xl font-black text-red-500 uppercase tracking-widest">CONNECTION SEVERED</h2>
                        <p className="text-xs font-mono text-red-800">KEYS_DESTROYED // LOGS_WIPED</p>
                    </div>
                )}
            </div>

            <button onClick={onClose} className="absolute top-6 right-6 p-2 text-green-700 hover:text-green-500 transition-colors z-50">
                <X size={24} />
            </button>

            <style>{`
                @keyframes scan { 0% { top: 0%; opacity: 0.5; } 100% { top: 100%; opacity: 0; } }
                @keyframes music-bar { 0%, 100% { height: 10%; } 50% { height: 90%; } }
                .loader { width: 12px; height: 12px; border: 2px solid white; border-bottom-color: transparent; border-radius: 50%; display: inline-block; animation: rotation 1s linear infinite; }
                @keyframes rotation { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } 
            `}</style>
        </div>
    );
};

// Simple Loader Component helper
const Loader2 = ({size, className}: {size: number, className?: string}) => (
    <div className={className} style={{ width: size, height: size, border: '2px solid currentColor', borderBottomColor: 'transparent', borderRadius: '50%', animation: 'rotation 1s linear infinite' }}></div>
);
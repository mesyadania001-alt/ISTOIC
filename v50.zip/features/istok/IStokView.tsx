import React, { useState, useEffect, useRef } from 'react';
import { 
    encryptData, decryptData
} from '../../utils/crypto'; 
import { SharedQRCode } from '../../components/SharedQRCode';
import { TeleponanView } from '../teleponan/TeleponanView';
import { activatePrivacyShield } from '../../utils/privacyShield';
import { 
    Send, Lock, Copy, 
    Wifi, ShieldCheck, ShieldAlert, 
    QrCode, X, CheckCircle2,
    Check, CheckCheck, Zap, ArrowRight, Radio, ScanLine, Server,
    Clock, Share2, RotateCcw,
    Mic, Square, Play, Pause, Image as ImageIcon,
    RefreshCw, Globe, SignalHigh, Leaf, Phone, HelpCircle, Ghost, Loader2, FileDown,
    UserPlus, History, BellRing, WifiOff, Network
} from 'lucide-react';
import useLocalStorage from '../../hooks/useLocalStorage';

// --- TYPES ---
interface Message {
    id: string;
    sender: 'ME' | 'THEM';
    type: 'TEXT' | 'IMAGE' | 'AUDIO';
    content: string; // Text or Base64
    timestamp: number;
    status: 'PENDING' | 'SENT' | 'DELIVERED' | 'READ';
    duration?: number; // For Audio
    size?: number; // Size in bytes
    isMasked?: boolean; // New flag for anonymized audio
}

interface SavedPeer {
    id: string;
    lastSeen: number;
    name?: string; // Optional nickname
}

type AppMode = 'SELECT' | 'HOST' | 'JOIN' | 'CHAT';
type ConnectionStage = 'IDLE' | 'LOCATING_PEER' | 'FETCHING_RELAYS' | 'VERIFYING_KEYS' | 'ESTABLISHING_TUNNEL' | 'SECURE' | 'RECONNECTING';

// --- ROBUST PUBLIC STUN LIST (Backup Only) ---
const TITANIUM_STUNS = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:global.stun.twilio.com:3478' }
];

// --- UTILS: NOTIFICATION MANAGER ---
const notifySystem = (title: string, body: string) => {
    if (Notification.permission === 'granted') {
        try {
            if (document.visibilityState === 'hidden') {
                new Notification(title, {
                    body: body,
                    icon: 'https://grainy-gradients.vercel.app/noise.svg',
                    vibrate: [200, 100, 200],
                    tag: 'istok-call' 
                } as any);
            }
        } catch (e) {
            console.warn("Notification failed", e);
        }
    }
};

// --- UTILS: AUDIO PROCESSING GRAPH (ANONYMIZER) ---
const createDistortionCurve = (amount: number) => {
    const k = typeof amount === 'number' ? amount : 50;
    const n_samples = 44100;
    const curve = new Float32Array(n_samples);
    const deg = Math.PI / 180;
    for (let i = 0; i < n_samples; ++i) {
        const x = (i * 2) / n_samples - 1;
        curve[i] = ((3 + k) * x * 20 * deg) / (Math.PI + k * Math.abs(x));
    }
    return curve;
};

// --- UTILS: METERED.CA TURN FETCHER (TCP/TLS FORCED) ---
const fetchMeteredIce = async (): Promise<any[]> => {
    const apiKey = (import.meta as any).env.VITE_METERED_API_KEY;
    const domain = (import.meta as any).env.VITE_METERED_DOMAIN;

    if (!apiKey || !domain) {
        console.log("Metered.ca not configured. Relay Mode disabled.");
        return [];
    }

    try {
        const url = `https://${domain}/api/v1/turn/credentials?apiKey=${apiKey}`;
        const response = await fetch(url);
        if (!response.ok) throw new Error("Metered API Failed");
        const iceServers = await response.json();
        
        const optimizedServers = iceServers.map((server: any) => {
            if (server.urls) {
                const urls = Array.isArray(server.urls) ? server.urls : [server.urls];
                const tcpUrls = urls.map((u: string) => {
                    if (u.startsWith('turn:') && !u.includes('transport=')) {
                        return `${u}?transport=tcp`;
                    }
                    if (u.startsWith('turns:') && !u.includes('transport=')) {
                        return `${u}?transport=tcp`;
                    }
                    return u;
                });
                return { ...server, urls: tcpUrls };
            }
            return server;
        });
        return optimizedServers;
    } catch (e) {
        return [];
    }
};

// --- UTILS: QUANTUM COMPRESSION ENGINE (EXTREME SAVER) ---
const compressImage = (file: File): Promise<{base64: string, size: number}> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 600; 
                const MAX_HEIGHT = 600;
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height *= MAX_WIDTH / width;
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width *= MAX_HEIGHT / height;
                        height = MAX_HEIGHT;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                const base64 = canvas.toDataURL('image/webp', 0.35); 
                const size = Math.round((base64.length * 3) / 4);
                resolve({ base64, size });
            };
            img.onerror = (err) => reject(err);
        };
        reader.onerror = (err) => reject(err);
    });
};

const AudioMessagePlayer: React.FC<{ src: string, duration?: number, isMasked?: boolean }> = ({ src, duration, isMasked }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const audioRef = useRef<HTMLAudioElement | null>(null);

    const togglePlay = () => {
        if (!audioRef.current) {
            audioRef.current = new Audio(src);
            audioRef.current.onended = () => setIsPlaying(false);
        }
        
        if (isPlaying) {
            audioRef.current.pause();
            setIsPlaying(false);
        } else {
            audioRef.current.play();
            setIsPlaying(true);
        }
    };

    return (
        <div className={`flex items-center gap-3 p-2 rounded-xl min-w-[140px] border ${isMasked ? 'bg-purple-900/20 border-purple-500/30' : 'bg-black/20 border-transparent'}`}>
            <button onClick={togglePlay} className={`w-8 h-8 rounded-full flex items-center justify-center hover:scale-105 transition-transform ${isMasked ? 'bg-purple-500 text-white' : 'bg-white text-black'}`}>
                {isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
            </button>
            <div className="flex flex-col">
                <div className="h-1 w-24 bg-white/20 rounded-full overflow-hidden">
                    <div className={`h-full transition-all duration-300 ${isPlaying ? 'animate-[pulse_1s_infinite]' : 'w-0'} ${isMasked ? 'bg-purple-400' : 'bg-white'}`} style={{width: isPlaying ? '100%' : '0%'}}></div>
                </div>
                <div className="flex items-center gap-1.5 mt-1">
                    {isMasked && <Ghost size={8} className="text-purple-400" />}
                    <span className={`text-[8px] font-mono ${isMasked ? 'text-purple-300' : 'text-neutral-400'}`}>
                        {isMasked ? 'MASKED_VOICE' : 'AUDIO'}
                    </span>
                </div>
            </div>
        </div>
    );
};

const triggerHaptic = (pattern: number | number[] = 10) => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(pattern);
    }
};

const playSound = (type: 'CONNECT' | 'MSG_IN' | 'MSG_OUT' | 'CALL_RING') => {
    try {
        const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext);
        if (!AudioContextClass) return;
        const ctx = new AudioContextClass();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        if (type === 'CONNECT') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.1);
            gain.gain.setValueAtTime(0.1, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
            osc.start();
            osc.stop(ctx.currentTime + 0.3);
        } else if (type === 'MSG_IN') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(500, ctx.currentTime);
            gain.gain.setValueAtTime(0.1, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
            osc.start();
            osc.stop(ctx.currentTime + 0.15);
        } else if (type === 'MSG_OUT') {
            osc.type = 'square';
            osc.frequency.setValueAtTime(200, ctx.currentTime);
            gain.gain.setValueAtTime(0.05, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
            osc.start();
            osc.stop(ctx.currentTime + 0.05);
        } else if (type === 'CALL_RING') {
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(800, ctx.currentTime);
            osc.frequency.linearRampToValueAtTime(1000, ctx.currentTime + 0.5);
            gain.gain.setValueAtTime(0.2, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.5);
            osc.start();
            osc.stop(ctx.currentTime + 1.5);
        }
    } catch (e) {}
};

const QRCodeModal: React.FC<{ link: string; pin: string; onClose: () => void }> = ({ link, pin, onClose }) => {
    const handleShare = async () => {
        if (navigator.share) {
            try { await navigator.share({ title: 'IStok Secure Channel', text: `Connect securely using PIN: ${pin}`, url: link }); } catch (err) {}
        } else { 
            try { await navigator.clipboard.writeText(link); alert('Link copied!'); } catch(e) {}
        }
    };

    return (
        <div className="fixed inset-0 z-[6000] bg-black/95 flex items-center justify-center p-6 animate-fade-in backdrop-blur-md" onClick={onClose}>
            <div className="bg-[#09090b] border border-white/10 p-8 rounded-[32px] max-w-sm w-full flex flex-col items-center gap-6 shadow-2xl relative" onClick={e => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-4 right-4 text-neutral-500 hover:text-white transition-colors p-2"><X size={20}/></button>
                <div className="text-center">
                    <h3 className="text-white font-black uppercase tracking-[0.2em] text-sm flex items-center justify-center gap-2"><QrCode size={16} className="text-emerald-500"/> LOCAL_KEY_EXCHANGE</h3>
                    <p className="text-[10px] text-neutral-500 mt-2 font-mono">Scan or Share to connect.</p>
                </div>
                <div className="p-4 bg-white rounded-2xl shadow-inner relative group select-none">
                    <SharedQRCode value={link} size={220} />
                </div>
                <div className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col items-center">
                    <span className="text-[9px] text-neutral-500 uppercase tracking-widest mb-1">DECRYPTION PIN</span>
                    <span className="text-3xl font-black text-white tracking-[0.3em] font-mono select-all">{pin}</span>
                </div>
                <button onClick={handleShare} className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"><Share2 size={14} /> SHARE SECURE LINK</button>
            </div>
        </div>
    );
};

const HelpModal: React.FC<{ onClose: () => void }> = ({ onClose }) => (
    <div className="fixed inset-0 z-[6000] bg-black/95 flex items-center justify-center p-6 animate-fade-in backdrop-blur-md" onClick={onClose}>
        <div className="bg-[#09090b] border border-white/10 p-8 rounded-[32px] max-w-md w-full relative shadow-2xl space-y-6" onClick={e => e.stopPropagation()}>
            <button onClick={onClose} className="absolute top-4 right-4 text-neutral-500 hover:text-white transition-colors"><X size={20}/></button>
            
            <div className="flex items-center gap-3">
                <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-500 border border-emerald-500/20">
                    <ShieldCheck size={24} />
                </div>
                <div>
                    <h3 className="text-lg font-black uppercase tracking-tight text-white">SECURE VOICE GUIDE</h3>
                    <p className="text-[10px] font-mono text-emerald-500 uppercase tracking-widest">WebRTC Encrypted Tunnel</p>
                </div>
            </div>
            <div className="space-y-4">
                <div className="flex gap-4 items-start">
                    <div className="w-6 h-6 rounded-full bg-white/10 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</div>
                    <p className="text-xs text-neutral-400 leading-relaxed"><strong className="text-white">AUTO-HEAL:</strong> If you switch from WiFi to Data, the app will automatically reconnect. Do not close the app.</p>
                </div>
                <div className="flex gap-4 items-start">
                    <div className="w-6 h-6 rounded-full bg-white/10 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</div>
                    <p className="text-xs text-neutral-400 leading-relaxed"><strong className="text-white">SAVED CONTACTS:</strong> Once connected, the peer is saved. You can call them directly next time.</p>
                </div>
            </div>
            <button onClick={onClose} className="w-full py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest text-white transition-all">ACKNOWLEDGE</button>
        </div>
    </div>
);

export const IStokView: React.FC = () => {
    // --- STATE ---
    const [mode, setMode] = useState<AppMode>('SELECT');
    const [stage, setStage] = useState<ConnectionStage>('IDLE');
    const stageRef = useRef<ConnectionStage>(stage); 
    
    // PERSISTENT MY ID to avoid changing link every reload
    const [storedMyId, setStoredMyId] = useLocalStorage<string>('istok_my_peer_id', '');
    const [myPeerId, setMyPeerId] = useState<string>(storedMyId);
    
    // SAVED CONTACTS
    const [savedPeers, setSavedPeers] = useLocalStorage<SavedPeer[]>('istok_saved_peers', []);

    const [targetPeerId, setTargetPeerId] = useState<string>('');
    const [accessPin, setAccessPin] = useState<string>('');
    
    const [showQR, setShowQR] = useState(false);
    const [showInfo, setShowInfo] = useState(false);
    const [showHelp, setShowHelp] = useState(false);
    
    // Teleponan Integration
    const [showCall, setShowCall] = useState(false);
    const [incomingCall, setIncomingCall] = useState<any>(null); // MediaConnection

    const [errorMsg, setErrorMsg] = useState<string>('');
    const [inputMsg, setInputMsg] = useState('');
    const [messages, setMessages] = useState<Message[]>([]);
    
    // Audio & Voice Masking
    const [isRecording, setIsRecording] = useState(false);
    const [isSendingAudio, setIsSendingAudio] = useState(false);
    const [recordingTime, setRecordingTime] = useState(0);
    const [isVoiceMasked, setIsVoiceMasked] = useState(false);
    
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const recordingIntervalRef = useRef<any>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    
    const [latency, setLatency] = useState<number>(0);
    const [peerTyping, setPeerTyping] = useState(false);
    const [isPeerOnline, setIsPeerOnline] = useState(false);
    const [connectionRetries, setConnectionRetries] = useState(0);
    const [isStuckLocating, setIsStuckLocating] = useState(false);
    const [usingRelay, setUsingRelay] = useState(false);
    const [isDataSaver, setIsDataSaver] = useState(false);

    const peerRef = useRef<any>(null);
    const connRef = useRef<any>(null);
    const msgEndRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const pinRef = useRef(accessPin); 
    const typingTimeoutRef = useRef<any>(null);
    const heartbeatIntervalRef = useRef<any>(null);
    const activityTimeoutRef = useRef<any>(null);
    const connectionTimeoutRef = useRef<any>(null);
    
    // AUTO-RECONNECT & HANDOVER LOGIC
    const reconnectIntervalRef = useRef<any>(null);
    const isReconnectingRef = useRef(false);
    const lastNetworkType = useRef<string | null>(null);

    // ACTIVATE SHIELD ON MOUNT & REQUEST NOTIFICATION
    useEffect(() => {
        activatePrivacyShield();
        if ("Notification" in window && Notification.permission !== "granted") {
            Notification.requestPermission();
        }
        
        // Restore Session from SessionStorage (The Black Box)
        try {
            const savedSession = sessionStorage.getItem('istok_active_session');
            if (savedSession) {
                const session = JSON.parse(savedSession);
                if (session.targetPeerId && session.accessPin) {
                    setTargetPeerId(session.targetPeerId);
                    setAccessPin(session.accessPin);
                    setMode('JOIN'); // Auto-trigger join logic on reload/recovery
                    // Wait slightly for peer init then join
                    setTimeout(() => joinSession(), 1000);
                }
            }
        } catch(e) {}
    }, []);

    useEffect(() => { 
        pinRef.current = accessPin;
        // Update Black Box
        if (targetPeerId && accessPin) {
            sessionStorage.setItem('istok_active_session', JSON.stringify({ targetPeerId, accessPin }));
        }
    }, [accessPin, targetPeerId]);

    useEffect(() => { stageRef.current = stage; }, [stage]);

    // NETWORK HANDOVER LISTENER (HYDRA-LINK)
    useEffect(() => {
        const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
        
        const handleNetworkChange = () => {
             const currentType = connection ? connection.effectiveType : 'unknown';
             console.log(`[HYDRA-LINK] Network changed: ${lastNetworkType.current} -> ${currentType}`);
             
             if (lastNetworkType.current && lastNetworkType.current !== currentType) {
                 // Network Switched (e.g. 4g -> wifi)
                 // WebRTC connection is likely dead or dying.
                 // FORCE RECONNECT IMMEDIATELY
                 if (mode === 'CHAT' && targetPeerId) {
                     console.log("[HYDRA-LINK] Initiating seamless handover...");
                     setErrorMsg("NETWORK SWITCH DETECTED. RE-ESTABLISHING TUNNEL...");
                     setStage('RECONNECTING');
                     
                     // Kill zombie connection
                     if (connRef.current) connRef.current.close();
                     
                     // Force re-dial with backoff reset
                     setConnectionRetries(0);
                     setTimeout(joinSession, 500); 
                 }
             }
             lastNetworkType.current = currentType;
             
             if (connection) {
                 setIsDataSaver(connection.saveData || connection.effectiveType === '2g' || connection.effectiveType === '3g');
             }
        };

        if (connection) {
            lastNetworkType.current = connection.effectiveType;
            connection.addEventListener('change', handleNetworkChange);
        }
        
        window.addEventListener('online', handleNetworkChange);
        window.addEventListener('offline', () => setErrorMsg("NO INTERNET CONNECTION"));

        return () => {
            if (connection) connection.removeEventListener('change', handleNetworkChange);
            window.removeEventListener('online', handleNetworkChange);
            window.removeEventListener('offline', () => {});
        };
    }, [mode, targetPeerId]);

    // --- INITIALIZATION ---
    useEffect(() => {
        let mounted = true;

        const initPeer = async () => {
            try {
                const { Peer } = await import('peerjs');
                if (!mounted) return;

                let iceServers: any[] = [];
                let transportPolicy: 'all' | 'relay' = 'all';

                try {
                    setStage('FETCHING_RELAYS');
                    const meteredServers = await fetchMeteredIce();
                    if (meteredServers.length > 0) {
                        setUsingRelay(true);
                        // IMPLEMENTASI FINAL: HANYA GUNAKAN SERVER RELAY JIKA TERSEDIA
                        iceServers = [...meteredServers];
                        transportPolicy = 'relay'; // FORCE RELAY (Stable Mode)
                    } else {
                        // FALLBACK KE STUN (Rumah Mode)
                        iceServers = [...TITANIUM_STUNS];
                        transportPolicy = 'all';
                        console.log("Relay not available. Falling back to STUN (P2P Direct).");
                    }
                } catch(e) {
                    iceServers = [...TITANIUM_STUNS];
                    transportPolicy = 'all';
                }

                // Use stored ID if available to persist identity
                const peerOptions: any = {
                    debug: 1,
                    secure: true, 
                    config: {
                        iceServers: iceServers,
                        iceCandidatePoolSize: 10,
                        iceTransportPolicy: transportPolicy, // FORCE RELAY or Fallback
                        bundlePolicy: 'max-bundle',
                        rtcpMuxPolicy: 'require' 
                    },
                    pingInterval: 5000, 
                };

                const peer = storedMyId ? new Peer(storedMyId, peerOptions) : new Peer(undefined, peerOptions);

                peer.on('open', (id) => {
                    if (mounted) {
                        setMyPeerId(id);
                        setStoredMyId(id); // Persist ID
                        setStage('IDLE');
                        setErrorMsg(''); // Clear error if reconnected
                        const hash = window.location.hash;
                        const params = new URLSearchParams(hash.substring(1));
                        if (params.get('connect')) {
                            setTargetPeerId(params.get('connect') || '');
                            setAccessPin(params.get('key') || '');
                            setMode('JOIN');
                        }
                        
                        // Check Black Box for Auto-Resume
                        const savedSession = sessionStorage.getItem('istok_active_session');
                        if (savedSession && !targetPeerId) {
                            const sess = JSON.parse(savedSession);
                            setTargetPeerId(sess.targetPeerId);
                            setAccessPin(sess.accessPin);
                        }

                        // If we were reconnecting, try joining back immediately
                        if (isReconnectingRef.current && targetPeerId) {
                            joinSession();
                        }
                    }
                });

                peer.on('connection', (conn) => handleIncomingConnection(conn));
                
                // --- INTEGRATED AUDIO CALL LISTENER (WITH NOTIFICATION) ---
                peer.on('call', (mediaConn) => {
                    setIncomingCall(mediaConn);
                    setShowCall(true);
                    playSound('CALL_RING');
                    notifySystem("INCOMING SECURE CALL", "Encrypted voice channel requesting connection...");
                });
                
                // --- ROBUST DISCONNECT HANDLING ---
                peer.on('disconnected', () => {
                     console.warn("Peer disconnected from signaling server. Attempting reconnect...");
                     setErrorMsg("SIGNALING LOST. RECONNECTING...");
                     // PeerJS specific: reconnect() allows reconnection to signaling server with same ID
                     setTimeout(() => {
                         if (peer && !peer.destroyed) peer.reconnect();
                     }, 1000);
                });

                peer.on('error', (err: any) => {
                    console.error("Peer Error:", err);
                    // Handle specifically relay connectivity issues
                    if (err.type === 'peer-unavailable') {
                        // Keep retry loop active in background
                        if (mode === 'CHAT') {
                             setErrorMsg("PEER LOST. RETRYING...");
                             // Exponential backoff for retry
                             if (!reconnectIntervalRef.current) {
                                 let attempt = 0;
                                 reconnectIntervalRef.current = setInterval(() => {
                                     attempt++;
                                     const delay = Math.min(1000 * Math.pow(1.5, attempt), 10000);
                                     console.log(`Auto-retry connection in ${delay}ms...`);
                                     setTimeout(joinSession, delay);
                                 }, 2000); // Check loop
                             }
                        } else {
                             setErrorMsg('TARGET OFFLINE or RELAY BLOCKED');
                        }
                    } else if (err.type === 'network') {
                        setErrorMsg('NETWORK FAIL: Check Internet');
                    } else if (err.type === 'unavailable-id') {
                        // If stored ID is taken (rare collision or zombie session), reset it
                        setStoredMyId('');
                        window.location.reload(); 
                    } else {
                        setErrorMsg(`CONN ERR: ${err.type}`);
                    }
                    
                    if (mode === 'JOIN') {
                        setConnectionRetries(prev => prev + 1);
                        if (connectionRetries < 20) { 
                            const delay = 1000 * Math.pow(1.1, connectionRetries); 
                            setTimeout(() => joinSession(), delay); 
                            return;
                        }
                    }
                    if (mode !== 'CHAT') setStage('IDLE');
                });

                peerRef.current = peer;

            } catch (e) { setErrorMsg("INIT_FAIL"); }
        };

        initPeer();

        return () => {
            mounted = false;
            peerRef.current?.destroy();
            clearInterval(heartbeatIntervalRef.current);
            clearTimeout(typingTimeoutRef.current);
            clearTimeout(activityTimeoutRef.current);
            clearTimeout(connectionTimeoutRef.current);
            clearInterval(recordingIntervalRef.current);
            clearInterval(reconnectIntervalRef.current);
        };
    }, []);

    useEffect(() => { msgEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages.length, peerTyping]);

    const startHeartbeat = () => {
        if (heartbeatIntervalRef.current) clearInterval(heartbeatIntervalRef.current);
        heartbeatIntervalRef.current = setInterval(async () => {
            if (connRef.current && connRef.current.open && pinRef.current) {
                const payload = JSON.stringify({ type: 'PING', time: Date.now() });
                const encrypted = await encryptData(payload, pinRef.current);
                if (encrypted) connRef.current.send({ type: 'SYS', payload: encrypted });
            }
        }, 5000); // Faster heartbeat for mobile stability
    };

    const updatePeerActivity = () => {
        setIsPeerOnline(true);
        if (activityTimeoutRef.current) clearTimeout(activityTimeoutRef.current);
        activityTimeoutRef.current = setTimeout(() => setIsPeerOnline(false), 15000);
        
        // Stop auto-retry if we get activity (Successful Handshake)
        if (reconnectIntervalRef.current) {
            clearInterval(reconnectIntervalRef.current);
            reconnectIntervalRef.current = null;
            setErrorMsg("");
            isReconnectingRef.current = false;
            if (stage === 'RECONNECTING') setStage('SECURE');
        }
    };

    const saveCurrentPeer = (id: string) => {
        setSavedPeers(prev => {
            const filtered = prev.filter(p => p.id !== id);
            return [{ id, lastSeen: Date.now() }, ...filtered].slice(0, 5); 
        });
    };

    const handleSavedPeerClick = (id: string) => {
        setTargetPeerId(id);
        if (accessPin) {
            setMode('JOIN');
            joinSession();
        } else {
            alert("Please enter PIN first to verify identity.");
            setMode('JOIN'); 
        }
    };

    const joinSession = () => {
        if (!targetPeerId || !accessPin) { setErrorMsg("MISSING_CREDENTIALS"); return; }
        
        if (mode !== 'CHAT') setStage('LOCATING_PEER');
        setErrorMsg('');
        setIsStuckLocating(false);
        if (connectionTimeoutRef.current) clearTimeout(connectionTimeoutRef.current);

        connectionTimeoutRef.current = setTimeout(() => {
            if (stageRef.current === 'LOCATING_PEER') {
                setIsStuckLocating(true);
                setErrorMsg("RELAY NEGOTIATION STALLED. RETRYING...");
                if (peerRef.current && !peerRef.current.destroyed) {
                    peerRef.current.reconnect();
                }
            }
        }, 12000);

        if (!peerRef.current || peerRef.current.destroyed) { window.location.reload(); return; }

        try {
            // Close existing connection if trying to reconnect to clean state
            if (connRef.current && !isReconnectingRef.current) {
                connRef.current.close();
            }

            const conn = peerRef.current.connect(targetPeerId, { 
                reliable: true, 
                serialization: 'json',
                metadata: { version: '25.0' },
                label: 'chat'
            });
            
            conn.peerConnection.oniceconnectionstatechange = () => {
                 const state = conn.peerConnection.iceConnectionState;
                 if(state === 'disconnected' || state === 'failed') {
                     // Don't show error immediately in Chat mode, try silent reconnect
                     if (mode !== 'CHAT') {
                         setErrorMsg("RELAY FAILED: BLOCKED BY FIREWALL");
                         setIsStuckLocating(true);
                     } else {
                         console.warn("ICE Failed/Disconnected. Triggering reconnect logic.");
                         isReconnectingRef.current = true;
                         setStage('RECONNECTING');
                     }
                 }
            };

            conn.on('open', async () => {
                if (connectionTimeoutRef.current) clearTimeout(connectionTimeoutRef.current);
                setIsStuckLocating(false);
                if (mode !== 'CHAT') setStage('VERIFYING_KEYS');
                connRef.current = conn;
                
                const payload = JSON.stringify({ type: 'SYN', timestamp: Date.now() });
                const encrypted = await encryptData(payload, accessPin);
                
                if (encrypted) conn.send({ type: 'HANDSHAKE', payload: encrypted });
                else { setErrorMsg("ENCRYPTION_FAIL"); setStage('IDLE'); }
            });

            conn.on('data', (data: any) => handleData(data));
            
            // STICKY SESSION LOGIC: Don't just close. Check if we want to persist.
            conn.on('close', () => {
                console.log("Connection closed.");
                handleDisconnect();
            });
            
            conn.on('error', (err: any) => { console.error("Conn Error", err); handleDisconnect(); });
        } catch (e) { setErrorMsg("CONNECT_FAIL"); }
    };

    const handleIncomingConnection = (conn: any) => {
        conn.on('data', async (data: any) => {
            if (data.type === 'HANDSHAKE') {
                const decrypted = await decryptData(data.payload, pinRef.current);
                if (decrypted) {
                    try {
                        const json = JSON.parse(decrypted);
                        if (json.type === 'SYN') {
                            connRef.current = conn;
                            setStage('SECURE');
                            setMode('CHAT'); 
                            setShowQR(false); 
                            playSound('CONNECT');
                            setTargetPeerId(conn.peer); 
                            saveCurrentPeer(conn.peer); // AUTO SAVE CONTACT
                            
                            notifySystem("SECURE LINK ESTABLISHED", "Peer handshake successful. Channel encrypted.");
                            
                            const ack = JSON.stringify({ type: 'ACK', timestamp: Date.now() });
                            const encAck = await encryptData(ack, pinRef.current);
                            conn.send({ type: 'HANDSHAKE_ACK', payload: encAck });
                            
                            startHeartbeat();
                            
                            // Stop any reconnection attempts
                            if (reconnectIntervalRef.current) {
                                clearInterval(reconnectIntervalRef.current);
                                reconnectIntervalRef.current = null;
                            }
                            isReconnectingRef.current = false;
                        }
                    } catch (e) {}
                } else {
                    conn.send({ type: 'ERROR', message: 'BAD_KEY' });
                    setTimeout(() => conn.close(), 200);
                }
            } else {
                handleData(data);
            }
        });
        // STICKY SESSION LOGIC
        conn.on('close', () => handleDisconnect());
        conn.on('error', () => handleDisconnect());
    };

    const handleData = async (packet: any) => {
        updatePeerActivity();

        if (packet.type === 'HANDSHAKE_ACK') {
            setStage('SECURE');
            setMode('CHAT');
            playSound('CONNECT');
            startHeartbeat();
            saveCurrentPeer(connRef.current?.peer); // AUTO SAVE ON ACK
            isReconnectingRef.current = false;
        } 
        else if (packet.type === 'MSG_ENC') {
            const decrypted = await decryptData(packet.payload, pinRef.current);
            if (decrypted) {
                const msg = JSON.parse(decrypted);
                if (connRef.current) {
                    connRef.current.send({ type: 'ACK_DELIVERED', id: msg.id });
                }
                setMessages(prev => [...prev, { ...msg, sender: 'THEM', status: 'READ' }]);
                playSound('MSG_IN');
                triggerHaptic(15);
                setPeerTyping(false);
                
                // NOTIFY ON BACKGROUND
                if (msg.type === 'TEXT') {
                     notifySystem("New Message", msg.content.substring(0, 50));
                } else if (msg.type === 'AUDIO') {
                     notifySystem("Voice Note", "Encrypted audio received.");
                } else if (msg.type === 'IMAGE') {
                     notifySystem("Secure Image", "Encrypted image received.");
                }
            }
        }
        else if (packet.type === 'ACK_DELIVERED') {
            setMessages(prev => prev.map(m => m.id === packet.id ? { ...m, status: 'DELIVERED' } : m));
        }
        else if (packet.type === 'SYS') {
            const decrypted = await decryptData(packet.payload, pinRef.current);
            if (decrypted) {
                const sysMsg = JSON.parse(decrypted);
                if (sysMsg.type === 'PING') {
                    const pong = JSON.stringify({ type: 'PONG', time: sysMsg.time });
                    const encPong = await encryptData(pong, pinRef.current);
                    if (encPong) connRef.current.send({ type: 'SYS', payload: encPong });
                }
                else if (sysMsg.type === 'PONG') {
                    setLatency(Date.now() - sysMsg.time);
                }
                else if (sysMsg.type === 'TYPING') {
                    setPeerTyping(sysMsg.status);
                    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
                    if (sysMsg.status) typingTimeoutRef.current = setTimeout(() => setPeerTyping(false), 4000);
                }
            }
        }
        else if (packet.type === 'ERROR') {
            setErrorMsg(packet.message);
            // Only go to idle if it's a critical error, not network flux
            if (packet.message === 'BAD_KEY') {
                setStage('IDLE');
            }
        }
    };

    const sendMessage = async (type: 'TEXT' | 'IMAGE' | 'AUDIO', content: string, duration?: number, size?: number, isMasked?: boolean) => {
        if (!connRef.current || !pinRef.current) return;
        const msgId = Date.now().toString(36).substr(-4) + Math.random().toString(36).substr(2, 3);
        const raw = JSON.stringify({ id: msgId, type, content, timestamp: Date.now(), duration, isMasked });
        const encrypted = await encryptData(raw, pinRef.current);
        if (encrypted) {
            setMessages(prev => [...prev, { id: msgId, sender: 'ME', type, content, timestamp: Date.now(), status: 'SENT', duration, size, isMasked }]);
            try {
                connRef.current.send({ type: 'MSG_ENC', payload: encrypted });
            } catch(e) {
                // If send fails, trigger reconnection logic
                console.warn("Send failed, attempting reconnect");
                handleDisconnect();
            }
            setInputMsg('');
            playSound('MSG_OUT');
            triggerHaptic(10);
        }
    };

    const handleTyping = async (e: React.ChangeEvent<HTMLInputElement>) => {
        setInputMsg(e.target.value);
        if (connRef.current && pinRef.current && stage === 'SECURE') {
            if ((window as any).typingThrottle) return;
            (window as any).typingThrottle = true;
            setTimeout(() => { (window as any).typingThrottle = false; }, 2000);

            const raw = JSON.stringify({ type: 'TYPING', status: true });
            const encrypted = await encryptData(raw, pinRef.current);
            if (encrypted) {
                 try { connRef.current.send({ type: 'SYS', payload: encrypted }); } catch(e) {}
            }
            
            if ((window as any).typingSendTimeout) clearTimeout((window as any).typingSendTimeout);
            (window as any).typingSendTimeout = setTimeout(async () => {
                const rawStop = JSON.stringify({ type: 'TYPING', status: false });
                const encStop = await encryptData(rawStop, pinRef.current);
                if (encStop && connRef.current) {
                    try { connRef.current.send({ type: 'SYS', payload: encStop }); } catch(e) {}
                }
            }, 1500);
        }
    };

    // --- VOICE ANONYMIZER (ANTI-CIA) ---
    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: { 
                    channelCount: 1, 
                    sampleRate: 16000, 
                    echoCancellation: true,
                    noiseSuppression: true
                } 
            });

            let recordingStream = stream;

            // If Masking is Enabled, process the audio
            if (isVoiceMasked) {
                const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext);
                const ctx = new AudioContextClass();
                audioContextRef.current = ctx;
                
                const source = ctx.createMediaStreamSource(stream);
                mediaStreamSourceRef.current = source;
                
                const dest = ctx.createMediaStreamDestination();
                
                // Chain 1: Low Cut (Remove Bass/Identity)
                const lowCut = ctx.createBiquadFilter();
                lowCut.type = "highpass";
                lowCut.frequency.value = 300; 

                // Chain 2: High Cut (Remove sibilance/clarity)
                const highCut = ctx.createBiquadFilter();
                highCut.type = "lowpass";
                highCut.frequency.value = 3000; 

                // Chain 3: Distortion (Digital Scramble)
                const distortion = ctx.createWaveShaper();
                distortion.curve = createDistortionCurve(50); 
                distortion.oversample = 'none';

                // Chain 4: Compressor (Flatten dynamics)
                const compressor = ctx.createDynamicsCompressor();
                compressor.threshold.value = -20;
                compressor.knee.value = 40;
                compressor.ratio.value = 12;
                compressor.attack.value = 0;
                compressor.release.value = 0.25;

                source.connect(lowCut);
                lowCut.connect(highCut);
                highCut.connect(distortion);
                distortion.connect(compressor);
                compressor.connect(dest);

                recordingStream = dest.stream;
            }

            const options = { mimeType: 'audio/webm;codecs=opus', audioBitsPerSecond: 16000 };
            mediaRecorderRef.current = new MediaRecorder(recordingStream, options);
            audioChunksRef.current = [];
            
            mediaRecorderRef.current.ondataavailable = (event) => {
                if (event.data.size > 0) audioChunksRef.current.push(event.data);
            };
            
            mediaRecorderRef.current.onstop = async () => {
                setIsSendingAudio(true); // Lock UI during processing
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                
                if (audioContextRef.current) {
                    audioContextRef.current.close();
                    audioContextRef.current = null;
                }
                
                stream.getTracks().forEach(t => t.stop());

                const reader = new FileReader();
                reader.onloadend = () => {
                    const base64 = reader.result as string;
                    sendMessage('AUDIO', base64, recordingTime, audioBlob.size, isVoiceMasked);
                    setIsSendingAudio(false); // Unlock
                };
                reader.readAsDataURL(audioBlob);
            };
            
            mediaRecorderRef.current.start();
            setIsRecording(true);
            setRecordingTime(0);
            recordingIntervalRef.current = setInterval(() => setRecordingTime(prev => prev + 1), 1000);
            triggerHaptic(50);
        } catch (e) { 
            console.error(e);
            alert("Mic Access Denied or Hardware Error"); 
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
            clearInterval(recordingIntervalRef.current);
            triggerHaptic(50);
        }
    };

    // --- STICKY SESSION HANDLER ---
    const handleDisconnect = () => {
        // Only return to SELECT/IDLE if we were not already securely chatting.
        // If we were chatting, this is likely a network drop, so we stay in CHAT mode and retry.
        if (mode === 'CHAT') {
            setIsPeerOnline(false);
            setStage('RECONNECTING');
            isReconnectingRef.current = true;
            
            // Auto-Retry Logic
            if (!reconnectIntervalRef.current) {
                console.log("Connection lost. Starting auto-reconnect sequence...");
                reconnectIntervalRef.current = setInterval(() => {
                    if (isReconnectingRef.current && targetPeerId) {
                        joinSession();
                    } else {
                        clearInterval(reconnectIntervalRef.current);
                        reconnectIntervalRef.current = null;
                    }
                }, 3000); 
            }
        } else {
            // Normal behavior for initial connection fails
            setStage('IDLE');
            setMode('SELECT'); 
            setErrorMsg("UPLINK_SEVERED");
            setMessages([]);
            sessionStorage.removeItem('istok_active_session'); // Clear session on explicit disconnect
        }
        
        setLatency(0);
        clearInterval(heartbeatIntervalRef.current);
    };

    const handleManualReconnect = () => {
        if (peerRef.current) {
            // Force destroy to get new candidates
            peerRef.current.destroy(); 
        }
        setTimeout(() => {
            // Reload page to force clean PeerJS state if deep issue
            window.location.reload();
        }, 500);
    };

    const forceExit = () => {
        // User explicitly wants to leave
        if (reconnectIntervalRef.current) clearInterval(reconnectIntervalRef.current);
        isReconnectingRef.current = false;
        if (connRef.current) connRef.current.close();
        setStage('IDLE');
        setMode('SELECT');
        setMessages([]);
        setTargetPeerId('');
        sessionStorage.removeItem('istok_active_session');
    };

    if (mode === 'SELECT') {
        return (
            <div className="h-[100dvh] w-full bg-[#050505] flex flex-col items-center justify-center px-6 pb-6 pt-[calc(env(safe-area-inset-top)+2rem)] space-y-12 animate-fade-in relative overflow-hidden font-sans">
                <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.03] pointer-events-none"></div>
                <div className="text-center space-y-4 z-10">
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-black uppercase tracking-[0.3em] text-emerald-500">
                        <ShieldCheck size={12}/> TITANIUM RELAY PROTOCOL v0.52
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black italic tracking-tighter text-white uppercase">
                        SECURE <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-500">TUNNEL</span>
                    </h1>
                    <p className="text-neutral-500 font-mono text-xs max-w-md mx-auto leading-relaxed">
                        AES-256 + FORCE TURN (TCP/443) + HYDRA-LINK HANDOVER. <br/>
                        {usingRelay ? "RELAY ACTIVE (CAFE/OFFICE READY)" : "RELAY OFFLINE (HOME MODE ONLY)"}
                    </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl z-10">
                    <button 
                        onClick={() => {
                            const randomPin = Math.floor(100000 + Math.random() * 900000).toString();
                            setAccessPin(randomPin);
                            setMode('HOST');
                        }}
                        className="group relative p-8 rounded-[32px] bg-zinc-900/50 border border-white/10 hover:border-emerald-500/50 transition-all duration-500 hover:bg-zinc-900 flex flex-col items-start gap-6 text-left ring-1 ring-transparent hover:ring-emerald-500/20"
                    >
                        <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 group-hover:scale-110 transition-transform border border-emerald-500/20">
                            <Server size={28} />
                        </div>
                        <div>
                            <h3 className="text-2xl font-black text-white uppercase italic tracking-tight mb-2">OPEN CHANNEL</h3>
                            <p className="text-xs text-neutral-400 font-medium leading-relaxed font-mono">Generate secure room (Host).</p>
                        </div>
                    </button>
                    <button 
                        onClick={() => setMode('JOIN')}
                        className="group relative p-8 rounded-[32px] bg-zinc-900/50 border border-white/10 hover:border-blue-500/50 transition-all duration-500 hover:bg-zinc-900 flex flex-col items-start gap-6 text-left ring-1 ring-transparent hover:ring-blue-500/20"
                    >
                        <div className="w-14 h-14 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-500 group-hover:scale-110 transition-transform border border-blue-500/20">
                            <ScanLine size={28} />
                        </div>
                        <div>
                            <h3 className="text-2xl font-black text-white uppercase italic tracking-tight mb-2">JOIN FREQUENCY</h3>
                            <p className="text-xs text-neutral-400 font-medium leading-relaxed font-mono">Connect via ID & Key (Guest).</p>
                        </div>
                    </button>
                </div>

                {/* SAVED CONTACTS "SPEED DIAL" */}
                {savedPeers.length > 0 && (
                    <div className="w-full max-w-lg z-10 space-y-4">
                         <div className="flex items-center justify-between text-neutral-500 text-[10px] font-black uppercase tracking-widest px-2">
                             <span>RECENT UPLINKS</span>
                             <span className="text-emerald-500">{savedPeers.length} SAVED</span>
                         </div>
                         <div className="grid grid-cols-1 gap-2">
                             {savedPeers.map(peer => (
                                 <button
                                     key={peer.id}
                                     onClick={() => handleSavedPeerClick(peer.id)}
                                     className="flex items-center gap-4 p-4 rounded-2xl bg-zinc-900/50 border border-white/5 hover:border-emerald-500/30 hover:bg-zinc-800 transition-all text-left group"
                                 >
                                     <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-500 border border-emerald-500/20 group-hover:scale-110 transition-transform">
                                         <UserPlus size={16} />
                                     </div>
                                     <div className="flex-1 min-w-0">
                                         <p className="text-white text-xs font-mono truncate">{peer.name || peer.id}</p>
                                         <p className="text-[9px] text-neutral-500 font-black uppercase tracking-wider mt-1 flex items-center gap-2">
                                             <History size={10} /> {new Date(peer.lastSeen).toLocaleDateString()}
                                         </p>
                                     </div>
                                     <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity">
                                         <Zap size={14} fill="currentColor" />
                                     </div>
                                 </button>
                             ))}
                         </div>
                    </div>
                )}

                {errorMsg && (
                    <div className="absolute bottom-10 px-6 py-3 bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl text-[10px] font-mono uppercase tracking-wider flex items-center gap-3 animate-slide-up">
                        <ShieldAlert size={14} /> {errorMsg}
                        <button onClick={() => setErrorMsg('')}><X size={12}/></button>
                    </div>
                )}
            </div>
        );
    }

    if (mode === 'HOST' || mode === 'JOIN') {
        const inviteLink = `${window.location.origin}${window.location.pathname}#connect=${myPeerId}&key=${accessPin}`;
        return (
            <div className="h-[100dvh] w-full bg-[#050505] flex flex-col items-center justify-center px-6 pb-6 pt-[calc(env(safe-area-inset-top)+2rem)] animate-fade-in relative font-sans">
                {mode === 'HOST' && showQR && <QRCodeModal link={inviteLink} pin={accessPin} onClose={() => setShowQR(false)} />}
                
                <button onClick={forceExit} className="absolute top-[calc(env(safe-area-inset-top)+1rem)] left-6 text-neutral-500 hover:text-white flex items-center gap-2 text-xs font-bold uppercase tracking-wider transition-colors z-20">
                    <ArrowRight className="rotate-180" size={14} /> ABORT
                </button>

                {mode === 'JOIN' && stage !== 'IDLE' ? (
                    <div className="text-center space-y-8 animate-fade-in">
                        <div className="relative w-24 h-24 mx-auto">
                            <div className="absolute inset-0 border-4 border-white/5 rounded-full"></div>
                            <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                            <div className="absolute inset-0 flex items-center justify-center">
                                {stage === 'LOCATING_PEER' && <Wifi size={32} className="text-blue-500 animate-pulse"/>}
                                {stage === 'FETCHING_RELAYS' && <Globe size={32} className="text-purple-500 animate-pulse"/>}
                                {stage === 'VERIFYING_KEYS' && <Lock size={32} className="text-amber-500 animate-pulse"/>}
                                {stage === 'SECURE' && <CheckCircle2 size={32} className="text-emerald-500"/>}
                                {stage === 'RECONNECTING' && <Network size={32} className="text-red-500 animate-bounce"/>}
                            </div>
                        </div>
                        <div>
                            <h2 className="text-xl font-black text-white uppercase tracking-tight mb-2">{stage.replace('_', ' ')}</h2>
                            <p className="text-xs text-neutral-500 font-mono">
                                {stage === 'FETCHING_RELAYS' ? 'Acquiring TURN (TCP/443)...' : 
                                 stage === 'RECONNECTING' ? 'HANDLING NETWORK SWITCHOVER...' :
                                 'Establishing Secure Tunnel...'}
                            </p>
                        </div>
                        {isStuckLocating && (
                            <button onClick={handleManualReconnect} className="px-6 py-3 bg-white text-black font-black uppercase text-[10px] tracking-widest rounded-xl hover:scale-105 transition-all shadow-lg flex items-center justify-center gap-2 mx-auto">
                                <RotateCcw size={14} /> FORCE RECONNECT
                            </button>
                        )}
                    </div>
                ) : mode === 'HOST' ? (
                    <div className="w-full max-w-md space-y-8 relative z-10">
                        <div className="text-center space-y-2">
                            <div className="w-20 h-20 mx-auto bg-emerald-500/10 rounded-full flex items-center justify-center mb-4 relative border border-emerald-500/20">
                                <div className="absolute inset-0 rounded-full border border-emerald-500/30 animate-ping"></div>
                                <Wifi size={32} className="text-emerald-500" />
                            </div>
                            <h2 className="text-2xl font-black text-white uppercase tracking-tight">BROADCASTING</h2>
                            <p className="text-xs text-neutral-400 font-mono">Waiting for peer handshake...</p>
                            {usingRelay && <span className="text-[9px] font-black uppercase tracking-widest text-purple-500 bg-purple-500/10 px-2 py-1 rounded border border-purple-500/20">RELAY: TCP/TLS SECURE</span>}
                        </div>
                        <div className="bg-[#09090b] border border-white/10 rounded-[32px] p-6 space-y-6 shadow-2xl">
                            <div>
                                <label className="text-[9px] font-black text-neutral-500 uppercase tracking-widest block mb-2 pl-1">CHANNEL ID</label>
                                <div className="flex gap-2">
                                    <code className="flex-1 bg-black p-4 rounded-xl text-xs text-emerald-400 font-mono truncate border border-white/5 select-all">{myPeerId || 'INITIALIZING...'}</code>
                                    <button onClick={() => navigator.clipboard.writeText(myPeerId)} className="p-4 bg-white/5 hover:bg-white/10 rounded-xl text-neutral-400 hover:text-white transition-colors"><Copy size={16}/></button>
                                </div>
                            </div>
                            <div>
                                <label className="text-[9px] font-black text-neutral-500 uppercase tracking-widest block mb-2 pl-1">PIN</label>
                                <div className="flex gap-2">
                                    <div className="flex-1 bg-black p-4 rounded-xl text-xl font-black text-white text-center tracking-[0.5em] border border-white/5 select-all font-mono">{accessPin}</div>
                                    <button onClick={() => setAccessPin(Math.floor(100000 + Math.random() * 900000).toString())} className="p-4 bg-white/5 hover:bg-white/10 rounded-xl text-neutral-400 hover:text-white transition-colors"><RefreshCw size={16}/></button>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3 pt-2">
                                <button onClick={() => setShowQR(true)} className="py-4 bg-white text-black rounded-xl font-black text-[10px] uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 shadow-lg"><QrCode size={16} /> SHOW QR</button>
                                <button onClick={async () => { if (navigator.share) await navigator.share({ title: 'IStok', text: `Pin: ${accessPin}`, url: inviteLink }); else try{ await navigator.clipboard.writeText(inviteLink); alert("Copied!"); }catch(e){} }} className="py-4 bg-white/5 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-white/10 transition-all flex items-center justify-center gap-2 border border-white/5"><Share2 size={16} /> SHARE LINK</button>
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="w-full max-w-md space-y-6 relative z-10">
                        <div className="text-center mb-8">
                            <h2 className="text-2xl font-black text-white uppercase tracking-tight">JOIN SECURE ROOM</h2>
                            <p className="text-xs text-neutral-400 font-mono mt-2">Enter credentials to establish uplink.</p>
                        </div>
                        <div className="space-y-4">
                            <div>
                                <label className="text-[9px] font-black text-neutral-500 uppercase tracking-widest block mb-2 pl-1">TARGET ID</label>
                                <input value={targetPeerId} onChange={(e) => setTargetPeerId(e.target.value)} placeholder="Paste ID here..." className="w-full bg-[#09090b] border border-white/10 rounded-2xl p-4 text-xs font-mono text-white focus:outline-none focus:border-blue-500 transition-all placeholder:text-neutral-700"/>
                            </div>
                            <div>
                                <label className="text-[9px] font-black text-neutral-500 uppercase tracking-widest block mb-2 pl-1">PIN</label>
                                <input value={accessPin} onChange={(e) => setAccessPin(e.target.value)} type="text" placeholder="000000" className="w-full bg-[#09090b] border border-white/10 rounded-2xl p-4 text-xl font-black text-white text-center tracking-[0.5em] focus:outline-none focus:border-blue-500 transition-all placeholder:text-neutral-800" maxLength={6}/>
                            </div>
                        </div>
                        <button onClick={joinSession} disabled={!targetPeerId || accessPin.length < 4} className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-black text-[10px] uppercase tracking-[0.2em] shadow-lg shadow-blue-900/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2">ESTABLISH UPLINK <Zap size={14} fill="currentColor"/></button>
                    </div>
                )}
            </div>
        );
    }

    return (
        <div className="h-[100dvh] w-full bg-[#050505] flex flex-col font-sans relative">
             {/* RECONNECTING OVERLAY */}
             {stage === 'RECONNECTING' && (
                 <div className="absolute top-0 left-0 right-0 z-50 bg-amber-500/90 text-black p-3 text-center animate-slide-down shadow-lg backdrop-blur-md">
                     <div className="flex items-center justify-center gap-3">
                         <WifiOff size={16} className="animate-pulse" />
                         <span className="text-[10px] font-black uppercase tracking-widest">NETWORK_FLUX_DETECTED. REBUILDING_TUNNEL...</span>
                         <button onClick={handleManualReconnect} className="px-3 py-1 bg-black/20 rounded-lg text-[9px] font-bold hover:bg-black/30 transition-all">HARD_RESET</button>
                     </div>
                 </div>
             )}

             {showCall && <TeleponanView onClose={() => { setShowCall(false); setIncomingCall(null); }} existingPeer={peerRef.current} initialTargetId={targetPeerId} incomingCall={incomingCall} />}
             {showHelp && <HelpModal onClose={() => setShowHelp(false)} />}

             <header className="h-auto pt-[calc(env(safe-area-inset-top)+1rem)] pb-4 px-4 md:px-6 border-b border-white/10 bg-[#09090b] flex items-center justify-between shrink-0 z-20">
                <div className="flex items-center gap-4">
                    <div className={`w-2.5 h-2.5 rounded-full ${isPeerOnline ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : (stage === 'RECONNECTING' ? 'bg-amber-500 animate-pulse' : 'bg-red-500')} transition-colors duration-500`}></div>
                    <div>
                        <h1 onClick={() => setShowInfo(!showInfo)} className="text-xs font-black tracking-[0.2em] text-white uppercase flex items-center gap-2 cursor-pointer hover:text-emerald-400 transition-colors">
                            IStok_P2P <span className="text-white/30">v0.52</span>
                            {latency > 0 && <span className={`text-[9px] px-1.5 py-0.5 rounded ${latency < 100 ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'}`}>{latency}ms</span>}
                        </h1>
                        <p className="text-[8px] text-emerald-500 font-mono flex items-center gap-1 mt-0.5">
                            <Lock size={8}/> AES-256 
                            {usingRelay && <span className="text-purple-500 flex items-center gap-1">| <SignalHigh size={8}/> FORCE_RELAY</span>}
                            {isDataSaver && <span className="text-amber-500 flex items-center gap-1">| <Leaf size={8}/> ECO_MODE</span>}
                        </p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                     <button onClick={() => setShowHelp(true)} className="p-2 text-neutral-500 hover:text-white hover:bg-white/10 rounded-lg transition-colors">
                        <HelpCircle size={16} />
                     </button>
                     <button onClick={() => setShowCall(true)} className={`p-2 bg-green-500/10 hover:bg-green-500 text-green-500 hover:text-white rounded-lg transition-colors border border-green-500/20 mr-2 flex items-center gap-2 ${isPeerOnline ? 'opacity-100' : 'opacity-50 cursor-not-allowed'}`} disabled={!isPeerOnline}>
                        <Phone size={16} />
                        <span className="hidden md:inline text-[9px] font-black">CALL</span>
                     </button>
                     <button onClick={forceExit} className="p-2 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-lg transition-colors border border-red-500/20">
                        <Radio size={16} />
                     </button>
                </div>
            </header>

            {showInfo && (
                <div className="absolute top-[calc(env(safe-area-inset-top)+4rem)] left-0 right-0 bg-black/90 backdrop-blur-md border-b border-white/10 p-4 z-30 animate-slide-down">
                    <div className="max-w-md mx-auto grid grid-cols-2 gap-4">
                        <div className="p-3 bg-white/5 rounded-xl">
                            <p className="text-[9px] text-neutral-500 uppercase font-black">PEER ID</p>
                            <code className="text-xs text-white block mt-1 truncate">{myPeerId}</code>
                        </div>
                        <div className="p-3 bg-white/5 rounded-xl">
                            <p className="text-[9px] text-neutral-500 uppercase font-black">PROTOCOL</p>
                            <p className="text-xs text-emerald-400 font-mono mt-1">FORCE_TURN_TCP</p>
                        </div>
                    </div>
                </div>
            )}

            <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 custom-scroll bg-noise pb-safe">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.sender === 'ME' ? 'justify-end' : 'justify-start'} animate-fade-in`}>
                        <div className={`max-w-[85%] md:max-w-[65%] flex flex-col ${msg.sender === 'ME' ? 'items-end' : 'items-start'}`}>
                            <div className={`p-3 md:p-4 rounded-[20px] text-sm font-medium leading-relaxed shadow-sm relative overflow-hidden ${msg.sender === 'ME' ? 'bg-blue-600 text-white rounded-tr-none shadow-blue-900/20' : 'bg-[#1a1a1a] text-neutral-200 border border-white/10 rounded-tl-none'}`}>
                                {msg.type === 'IMAGE' ? (
                                    <div className="flex flex-col">
                                        <img src={msg.content} alt="Secure Image" className="rounded-lg max-w-full border border-black/20" />
                                        {msg.size && <span className="text-[8px] opacity-50 mt-1 self-end font-mono">{(msg.size / 1024).toFixed(1)} KB</span>}
                                    </div>
                                ) : msg.type === 'AUDIO' ? (
                                    <div className="flex flex-col">
                                        <AudioMessagePlayer src={msg.content} duration={msg.duration} isMasked={msg.isMasked} />
                                        {msg.size && <span className="text-[8px] opacity-50 mt-1 self-end font-mono">{(msg.size / 1024).toFixed(1)} KB</span>}
                                    </div>
                                ) : ( msg.content )}
                            </div>
                            <div className="flex items-center gap-1.5 mt-1 px-1">
                                <span className="text-[8px] text-neutral-600 font-mono">{new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                {msg.sender === 'ME' && (
                                    <span className="flex items-center" title={msg.status}>
                                        {msg.status === 'PENDING' && <Clock size={10} className="text-neutral-500"/>}
                                        {msg.status === 'SENT' && <Check size={12} className="text-neutral-500"/>}
                                        {msg.status === 'DELIVERED' && <CheckCheck size={12} className="text-neutral-500"/>}
                                        {msg.status === 'READ' && <CheckCheck size={12} className="text-blue-500"/>}
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
                {peerTyping && (
                    <div className="flex justify-start animate-fade-in">
                        <div className="bg-[#1a1a1a] border border-white/10 rounded-[20px] rounded-tl-none p-3 md:p-4 flex items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full animate-bounce"></div>
                            <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full animate-bounce delay-100"></div>
                            <div className="w-1.5 h-1.5 bg-neutral-500 rounded-full animate-bounce delay-200"></div>
                        </div>
                    </div>
                )}
                <div ref={msgEndRef} />
            </div>

            <div className="p-3 md:p-4 bg-[#09090b] border-t border-white/10 shrink-0 pb-safe">
                <div className="max-w-4xl mx-auto flex items-end gap-2 md:gap-3">
                    <button onClick={() => fileInputRef.current?.click()} disabled={isSendingAudio} className="p-3 text-neutral-500 hover:text-white bg-white/5 hover:bg-white/10 rounded-2xl transition-colors border border-white/5 disabled:opacity-50">
                        <ImageIcon size={20} />
                    </button>
                    
                    {/* Voice Mask Toggle */}
                    <button 
                        onClick={() => setIsVoiceMasked(!isVoiceMasked)}
                        disabled={isSendingAudio}
                        className={`p-3 rounded-2xl transition-colors border ${isVoiceMasked ? 'bg-purple-900/30 text-purple-400 border-purple-500/50' : 'bg-white/5 text-neutral-500 border-white/5 hover:text-white'} disabled:opacity-50`}
                        title="Ghost Mode (Voice Masking)"
                    >
                        <Ghost size={20} />
                    </button>

                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                            compressImage(file).then(({base64, size}) => sendMessage('IMAGE', base64, 0, size)).catch(err => alert("Compression Failed"));
                        }
                    }} />
                    
                    <div className="flex-1 bg-white/5 rounded-2xl border border-white/5 focus-within:border-blue-500/50 transition-all flex items-center">
                        <input value={inputMsg} onChange={handleTyping} onKeyDown={(e) => e.key === 'Enter' && sendMessage('TEXT', inputMsg)} placeholder={isRecording ? (isVoiceMasked ? "GHOST MODE ACTIVE..." : "Recording...") : "Encrypted message..."} disabled={isRecording || isSendingAudio} className="w-full bg-transparent p-3 md:p-4 text-sm text-white focus:outline-none placeholder:text-neutral-600"/>
                    </div>
                    
                    {inputMsg.trim() ? (
                        <button onClick={() => sendMessage('TEXT', inputMsg)} disabled={isSendingAudio} className="p-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl shadow-lg transition-all disabled:opacity-50"><Send size={20} /></button>
                    ) : (
                        <button 
                            onMouseDown={startRecording} 
                            onMouseUp={stopRecording} 
                            onTouchStart={(e) => { e.preventDefault(); startRecording(); }} 
                            onTouchEnd={(e) => { e.preventDefault(); stopRecording(); }} 
                            disabled={isSendingAudio}
                            className={`p-3 rounded-2xl shadow-lg transition-all border ${
                                isRecording 
                                ? (isVoiceMasked ? 'bg-purple-600 border-purple-700 text-white scale-110 shadow-purple-500/50' : 'bg-red-500 border-red-600 text-white scale-110') 
                                : isSendingAudio 
                                    ? 'bg-white/10 border-white/20 text-white cursor-wait'
                                    : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white'
                            }`}
                        >
                            {isSendingAudio ? <Loader2 size={20} className="animate-spin" /> : isRecording ? (isVoiceMasked ? <Ghost size={20} fill="currentColor"/> : <Square size={20} fill="currentColor"/>) : <Mic size={20} />}
                        </button>
                    )}
                </div>
                {isRecording && <p className={`text-center text-[9px] font-black mt-2 animate-pulse uppercase tracking-widest ${isVoiceMasked ? 'text-purple-500' : 'text-red-500'}`}>{isVoiceMasked ? 'GHOST PROTOCOL' : 'RECORDING AUDIO'}... {recordingTime}s</p>}
                {isSendingAudio && <p className="text-center text-[9px] font-black mt-2 animate-pulse uppercase tracking-widest text-blue-500">ENCRYPTING & UPLOADING...</p>}
            </div>
        </div>
    );
};